self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1a1465e96256e60ef2615ffcb4d1b3ad",
    "url": "/.htaccess"
  },
  {
    "revision": "eb37571f85360ba2abdbd299dbffbb2d",
    "url": "/assets/img/login3.png"
  },
  {
    "revision": "46bc4b1eab2da0e2131b",
    "url": "/css/app.d768b257.css"
  },
  {
    "revision": "283b30958bcb08e356df",
    "url": "/css/chunk-vendors.ca31118d.css"
  },
  {
    "revision": "82a31ee45c465bcb7e96f5f9135584c5",
    "url": "/css/font.css"
  },
  {
    "revision": "a43d7d1cc577580f02c44396d1b35fcc",
    "url": "/css/icon.css"
  },
  {
    "revision": "1ba2ae710d927f13d483fd5d1e548c9b",
    "url": "/faviconasd.ico"
  },
  {
    "revision": "39bfea5e86f5f41c9d2896dbbed6791b",
    "url": "/fonts/MaterialIcons-Regular.39bfea5e.woff"
  },
  {
    "revision": "ae8b1248595e70a828b880b9c56963da",
    "url": "/fonts/MaterialIcons-Regular.ae8b1248.eot"
  },
  {
    "revision": "b073f5972d9c4cc1b8ae8e071e441376",
    "url": "/fonts/MaterialIcons-Regular.b073f597.woff2"
  },
  {
    "revision": "b9968c1adf542baec8d2b298d3ff437c",
    "url": "/fonts/MaterialIcons-Regular.b9968c1a.ttf"
  },
  {
    "revision": "3eb5459d91a5743e0deaf2c7d7896b08",
    "url": "/fonts/OpenSans.3eb5459d.ttf"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "147e3378b44bc9570418b1eece10dd7c",
    "url": "/fonts/materialdesignicons-webfont.147e3378.woff"
  },
  {
    "revision": "174c02fc4609e8fc4389f5d21f16a296",
    "url": "/fonts/materialdesignicons-webfont.174c02fc.ttf"
  },
  {
    "revision": "64d4cf64afd77a4ad2713f648eb920e6",
    "url": "/fonts/materialdesignicons-webfont.64d4cf64.eot"
  },
  {
    "revision": "7a44ea195f395e1d086010e44555a5c4",
    "url": "/fonts/materialdesignicons-webfont.7a44ea19.woff2"
  },
  {
    "revision": "6c7811e6bd9bc167cea7b3976b223cf4",
    "url": "/img/0.1.5/1.JPG"
  },
  {
    "revision": "ec51bf17f56553570827b88588ee976f",
    "url": "/img/0.1.5/2.JPG"
  },
  {
    "revision": "4ff34e071fabb92477de7e8ca8c2923c",
    "url": "/img/0.1.5/3.JPG"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "3c8df4814a7d1392b8e072dcc3cdad0e",
    "url": "/img/login-image.3c8df481.png"
  },
  {
    "revision": "aa6676e24b7d3179077a9c06e1a8a8c0",
    "url": "/index.html"
  },
  {
    "revision": "46bc4b1eab2da0e2131b",
    "url": "/js/app.5b8020a1.js"
  },
  {
    "revision": "283b30958bcb08e356df",
    "url": "/js/chunk-vendors.f1dca350.js"
  },
  {
    "revision": "29fce7f29a727f713236dc48bb49cb0f",
    "url": "/logo-mjc-foil.png"
  },
  {
    "revision": "c76f99505a94d9123fb0cddfb6ed7db4",
    "url": "/logolong.png"
  },
  {
    "revision": "048ee77370054da00dca44c636790f31",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);